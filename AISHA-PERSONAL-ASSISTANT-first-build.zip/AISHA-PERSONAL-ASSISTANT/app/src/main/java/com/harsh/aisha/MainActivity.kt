package com.harsh.aisha

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Night = Color(0xFF090B17)
private val Panel = Color(0xFF14182A)
private val Panel2 = Color(0xFF1D2238)
private val Purple = Color(0xFF8C67FA)
private val Teal = Color(0xFF45DCC9)
private val Muted = Color(0xFF9DA6BE)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
        setContent { AishaApp(onSpeak = { speak(it) }) }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aisha_reply") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun AishaApp(onSpeak: (String) -> Unit) {
    var screen by remember { mutableStateOf("Home") }
    var selectedModel by remember { mutableIntStateOf(1) }
    var selectedView by remember { mutableStateOf("Half body") }
    var selectedOutfit by remember { mutableStateOf("Everyday casual") }
    var aiEnabled by remember { mutableStateOf(false) }
    var wakeEnabled by remember { mutableStateOf(false) }
    var savedMemory by remember { mutableStateOf("Hindi/Hinglish • friendly replies") }
    var reminder by remember { mutableStateOf("Accountancy revision • 7:00 PM") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Purple, secondary = Teal,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D1020), contentColor = Color.White) {
                    listOf("Home", "Avatar", "Memory", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item },
                            icon = {
                                Icon(when(item) {
                                    "Home" -> Icons.Default.Home
                                    "Avatar" -> Icons.Default.Face
                                    "Memory" -> Icons.Default.Bookmark
                                    else -> Icons.Default.Settings
                                }, contentDescription = item)
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Teal, selectedTextColor = Color.White,
                                indicatorColor = Panel2, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when(screen) {
                "Home" -> HomeScreen(padding, onSpeak, { screen = "Conversation" }, { screen = "Reminders" })
                "Avatar" -> AvatarScreen(padding, selectedModel, { selectedModel = it }, selectedView, { selectedView = it }, selectedOutfit, { selectedOutfit = it }, onSpeak)
                "Memory" -> MemoryScreen(padding, savedMemory, { savedMemory = it })
                "Settings" -> SettingsScreen(padding, wakeEnabled, { wakeEnabled = it }, aiEnabled, { aiEnabled = it }, onSpeak, { screen = "Privacy" })
                "Conversation" -> ConversationScreen(padding, onSpeak)
                "Reminders" -> RemindersScreen(padding, reminder, { reminder = it })
                else -> SimpleScreen(padding, "Privacy & Safety", "Camera/microphone should only be used with clear permission and visible status.")
            }
        }
    }
}

@Composable
private fun ScreenColumn(padding: PaddingValues, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).background(Night).padding(horizontal = 20.dp)) { content() }
}
@Composable
private fun Eyebrow(text: String) { Text(text.uppercase(), color = Teal, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp) }
@Composable
private fun Header(title: String, subtitle: String? = null) {
    Spacer(Modifier.height(18.dp)); Eyebrow("AISHA • PERSONAL AI")
    Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
    if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(18.dp))
}
@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(16.dp), content = content)
}
@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
private fun AvatarIllustration(size: Int = 150, variant: Int = 0) {
    val colors = listOf(Purple, Teal, Color(0xFFF36CA6), Color(0xFFE6A16D), Color(0xFF8EA7FF))
    Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(listOf(colors[(variant-1).coerceIn(0,4)], Panel2))), contentAlignment = Alignment.Center) {
        Box(Modifier.size((size*0.69).dp).clip(CircleShape).background(Color(0xFF21172A)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size((size*0.42).dp).clip(RoundedCornerShape(45)).background(Color(0xFFD9A68B)), contentAlignment = Alignment.Center) {
                    Row(horizontalArrangement = Arrangement.spacedBy((size*0.10).dp)) {
                        Box(Modifier.size(5.dp).clip(CircleShape).background(Night))
                        Box(Modifier.size(5.dp).clip(CircleShape).background(Night))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width((size*0.32).dp).height(3.dp).clip(CircleShape).background(Color(0xFFE9829A)))
                Spacer(Modifier.height(6.dp))
                Box(Modifier.width((size*0.52).dp).height((size*0.19).dp).clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(Color(0xFFE7E9F3)))
            }
        }
        Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(10.dp).clip(CircleShape).background(Teal))
    }
}
@Composable
private fun HomeScreen(padding: PaddingValues, onSpeak: (String)->Unit, openChat: ()->Unit, openReminders: ()->Unit) {
    ScreenColumn(padding) {
        Header("Hey, Harsh", "I'm here when you need me.")
        CardBox {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AvatarIllustration(165) }
            Spacer(Modifier.height(12.dp))
            Text("Aisha", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Ready when you are • Prototype mode", color = Teal, fontSize = 11.sp)
            Spacer(Modifier.height(14.dp))
            PrimaryButton("🎙  Talk to Aisha") { onSpeak("Namaste Harsh, main Aisha hoon. Abhi main prototype mode mein hoon."); openChat() }
        }
        Spacer(Modifier.height(20.dp)); Text("Quick actions", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickTile("Reminder", Icons.Default.Notifications, Modifier.weight(1f), openReminders)
            QuickTile("Memory", Icons.Default.Bookmark, Modifier.weight(1f)) { onSpeak("Memory screen par tum apni saved preferences dekh sakte ho.") }
            QuickTile("Avatar", Icons.Default.Face, Modifier.weight(1f)) { onSpeak("Avatar studio kholo aur model, view aur outfit select karo.") }
        }
        Spacer(Modifier.height(16.dp))
        Text("Local-first • External AI optional", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
    }
}
@Composable
private fun QuickTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: ()->Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).clickable { onClick() }.padding(vertical = 15.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Teal); Spacer(Modifier.height(7.dp)); Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
@Composable
private fun AvatarScreen(padding: PaddingValues, model: Int, setModel: (Int)->Unit, view: String, setView: (String)->Unit, outfit: String, setOutfit: (String)->Unit, onSpeak: (String)->Unit) {
    ScreenColumn(padding) {
        Header("Avatar Studio", "5 character slots • 3 views per model")
        CardBox {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AvatarIllustration(175, model) }
            Spacer(Modifier.height(10.dp))
            Text("Model %02d".format(model), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Illustrative placeholder — real rigged 3D models are a later integration.", color = Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(18.dp)); Text("Choose a model", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            (1..5).forEach { n ->
                Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if(model==n) Panel2 else Panel).clickable { setModel(n) }.padding(vertical=10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AvatarIllustration(42, n); Text("$n", color = if(model==n) Teal else Muted, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(18.dp)); Text("View", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Close-up","Half body","Full body").forEach { v -> FilterChip(selected = view==v, onClick={setView(v)}, label={Text(v,fontSize=10.sp)}) }
        }
        Spacer(Modifier.height(18.dp)); Text("Outfit", fontWeight = FontWeight.Bold)
        listOf("Everyday casual","Traditional","Smart","Comfy homewear").forEach { o ->
            Row(Modifier.fillMaxWidth().clickable { setOutfit(o); onSpeak("Outfit selected: $o") }.padding(vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                RadioButton(selected=outfit==o,onClick={setOutfit(o)})
                Column(Modifier.weight(1f)) { Text(o); Text("Compatible outfit slot", color=Muted, fontSize=10.sp) }
            }
        }
        PrimaryButton("Apply selected look") { onSpeak("Model $model, $view view, $outfit outfit selected.") }
        Spacer(Modifier.height(18.dp))
    }
}
@Composable
private fun MemoryScreen(padding: PaddingValues, memory: String, setMemory: (String)->Unit) {
    ScreenColumn(padding) {
        Header("What I remember", "Local prototype memory • editable")
        CardBox {
            Text("Saved preference", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value=memory,onValueChange=setMemory,label={Text("Your memory")},modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text("Prototype note: this demo keeps the value in screen state; persistent Room storage will be added in a later build.", color=Muted, fontSize=11.sp)
        }
        Spacer(Modifier.height(16.dp))
        CardBox {
            Text("Privacy controls", fontWeight=FontWeight.Bold)
            Text("Review, edit or clear what Aisha remembers. No cloud memory is connected in this build.", color=Muted, fontSize=12.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick={setMemory("")}) { Text("Clear memory") }
        }
    }
}
@Composable
private fun SettingsScreen(padding: PaddingValues, wake: Boolean, setWake:(Boolean)->Unit, ai:Boolean, setAi:(Boolean)->Unit, onSpeak:(String)->Unit, openPrivacy:()->Unit) {
    ScreenColumn(padding) {
        Header("Settings", "Voice, AI connection and privacy")
        CardBox {
            Text("Wake word", fontWeight=FontWeight.Bold)
            Text("Switch is a prototype setting; always-on wake-word engine is not connected yet.", color=Muted, fontSize=11.sp)
            Switch(checked=wake,onCheckedChange=setWake)
            Divider(color=Panel2)
            Text("Optional external AI", fontWeight=FontWeight.Bold)
            Text("AI provider is not connected in this build. Local demo controls remain available.", color=Muted, fontSize=11.sp)
            Switch(checked=ai,onCheckedChange=setAi)
        }
        Spacer(Modifier.height(14.dp))
        CardBox {
            Text("Phone controls", fontWeight=FontWeight.Bold)
            Text("No calls, SMS or third-party app automation is enabled in this prototype.", color=Muted, fontSize=12.sp)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick=openPrivacy) { Text("Privacy & safety") }
        }
        Spacer(Modifier.height(14.dp))
        PrimaryButton("Test spoken reply") { onSpeak("Namaste Harsh. Aisha ka voice output kaam kar raha hai, agar device ki Hindi voice installed hai.") }
    }
}
@Composable
private fun ConversationScreen(padding: PaddingValues, onSpeak:(String)->Unit) {
    var message by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Hey Harsh! Main abhi UI prototype hoon. Local commands aur AI API agle integration builds mein connect honge.") }
    ScreenColumn(padding) {
        Header("Talk with Aisha", "Voice + conversation prototype")
        CardBox {
            Text("Aisha", color=Teal, fontWeight=FontWeight.Bold)
            Text(reply, modifier=Modifier.padding(top=8.dp), fontSize=14.sp)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value=message,onValueChange={message=it},modifier=Modifier.fillMaxWidth(),label={Text("Message Aisha…")})
        Spacer(Modifier.height(8.dp))
        PrimaryButton("Send") {
            reply = if(message.contains("remind",true) || message.contains("yaad",true)) "Reminder screen par jaakar apna reminder set karo. Abhi actual alarm integration nahi hai."
            else "Message received in prototype. External AI provider abhi connected nahi hai."
            onSpeak(reply)
        }
        Spacer(Modifier.height(8.dp))
        Text("Offline UI demo • no external request is sent.", color=Muted, fontSize=11.sp)
    }
}
@Composable
private fun RemindersScreen(padding: PaddingValues, current: String, setReminder:(String)->Unit) {
    ScreenColumn(padding) {
        Header("Reminders", "Reminder UI prototype")
        CardBox {
            Text("Current reminder", fontWeight=FontWeight.Bold)
            Text(current, color=Teal, modifier=Modifier.padding(vertical=10.dp))
            OutlinedTextField(value=current,onValueChange=setReminder,label={Text("Reminder text")},modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Text("This build does not schedule a real alarm yet.", color=Muted, fontSize=11.sp)
        }
    }
}
@Composable
private fun SimpleScreen(padding: PaddingValues, title:String, body:String) {
    ScreenColumn(padding) { Header(title, body); CardBox { Text(body, color=Muted) } }
}
