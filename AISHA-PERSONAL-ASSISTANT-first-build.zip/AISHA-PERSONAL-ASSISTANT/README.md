# Aisha Personal AI Assistant — UI Prototype

Android-first Kotlin + Jetpack Compose starter matching the initial Figma screen direction.

## Current prototype
- Dark purple/teal theme and bottom navigation
- Home, conversation demo, avatar studio, model selector (5 visual placeholders), three view selectors, outfit selector
- Memory/settings/reminders/privacy placeholder screens
- Android TextToSpeech spoken test response
- No external AI requests, no wake-word engine, no real 3D models, no persistent Room storage, no real alarm scheduling, and no call/SMS automation in this build.

## Build
The repository includes a GitHub Actions workflow that installs Gradle and Android SDK, then builds a debug APK. This starter intentionally omits the Gradle wrapper binary so the workflow uses the Gradle setup action.
